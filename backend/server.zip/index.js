const express=require('express')
const path=require('path')
const app=express()
const port=7007
require('./auth');
app.use(express.json())
app.use(express.static(path.join(__dirname, 'frontend')));
const passport=require('passport')
const session=require('express-session')
const Invoice = require('./models/Invioces');
const connectDB = require("./connectDB")

function isLoggedIn(req, res, next){
    req.user ? next():res.sendStatus(401)
}

app.get('/', (req, res)=>{
    res.sendFile('index.html')
})

connectDB();
app.use(session({
    secret: 'mysecret',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: true }
  }))

app.use(passport.initialize());
app.use(passport.session());
app.get('/auth/google',passport.authenticate('google', { scope:
        [ 'email', 'profile' ] }
  ));
  
  app.get( '/auth/google/callback',
      passport.authenticate( 'google', {
          successRedirect: '/auth/google/success',
          failureRedirect: '/auth/google/failure'
  }));
  app.get('/auth/google/failure', isLoggedIn, (req, res)=>{
    res.send('Something went wrong!');
  })

  app.get('/auth/protected', isLoggedIn, (req, res)=>{
    let name=req.user.displayName
    res.send(`Hello ${name}`);
  })

  app.use('/auth/logout', (req, res)=>{
    req.session.destroy();
    res.send('See you again!');
  });

  app.get('/invoices', async (req, res) => {
    try {
      const invoices = await Invoice.find();
      res.json(invoices);
    } catch (err) {
      res.status(500).send(err);
    }
  });
  
  // Get a specific invoice
  app.get('/invoices/:id', async (req, res) => {
    try {
      const invoice = await Invoice.findById(req.params.id);
      if (!invoice) return res.status(404).send('Invoice not found');
      res.json(invoice);
    } catch (err) {
      res.status(500).send(err);
    }
  });
  
  // Create a new invoice
  app.post('/invoices', async (req, res) => {
    try {
      const invoice = new Invoice(req.body);
      await invoice.save();
      res.status(201).json(invoice);
    } catch (err) {
      res.status(500).send(err);
    }
  });
  
  // Update an invoice
  app.put('/invoices/:id', async (req, res) => {
    try {
      const invoice = await Invoice.findByIdAndUpdate(req.params.id, req.body, { new: true });
      if (!invoice) return res.status(404).send('Invoice not found');
      res.json(invoice);
    } catch (err) {
      res.status(500).send(err);
    }
  });
  
  // Delete an invoice
  app.delete('/invoices/:id', async (req, res) => {
    try {
      const invoice = await Invoice.findByIdAndDelete(req.params.id);
      if (!invoice) return res.status(404).send('Invoice not found');
      res.send('Invoice deleted');
    } catch (err) {
      res.status(500).send(err);
    }
  });
  
  // Endpoint to trigger Zapier automation for past-due invoices
  app.post('/zapier/past-due', async (req, res) => {
    try {
        const { invoiceId, zapierWebhookUrl } = req.body;
        console.log(zapierWebhookUrl)
        const invoice = await Invoice.findById(invoiceId);
        console.log(invoice)
        if (!invoice) return res.status(404).send('Invoice not found');
        //   if (invoice.status !== 'due') return res.status(400).send('Invoice is not past-due');
        
        // Send data to Zapier
        await axios.post(zapierWebhookUrl, { invoice });
        
        console.log("helooooooooo")
  
      res.send('Zapier notification sent');
    } catch (err) {
      res.status(500).send(err);
    }
  });
  
  // Check and update past-due invoices
  app.post('/invoices/check-past-due', async (req, res) => {
    try {
      const invoices = await Invoice.find({ dueDate: { $lt: new Date() }, status: 'due' });
  
      for (const invoice of invoices) {
        invoice.status = 'past-due';
        await invoice.save();
  
        // Trigger Zapier webhook for past-due invoices
        await axios.post('YOUR_ZAPIER_WEBHOOK_URL', { invoice });
      }
  
      res.send('Past-due invoices checked and updated');
    } catch (err) {
      res.status(500).send(err);
    }
  });

app.listen(port,()=>{
    console.log(`Listening on port ${port}`)
})