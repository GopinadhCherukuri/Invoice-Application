// models/Invoice.js
const mongoose = require('mongoose');

const invoiceSchema = new mongoose.Schema({
  amount: {
    type: Number,
    required: true,
    min: [0, 'Amount cannot be negative']
  },
  dueDate: {
    type: Date,
    required: true
  },
  recipient: {
    type: String,
    required: true,
    trim: true
  },
  status: {
    type: String,
    enum: ['due', 'paid', 'overdue'],
    default: 'due'
  }
}, {
  timestamps: true
});

const Invoice = mongoose.model('Invoice', invoiceSchema);

module.exports = Invoice;

